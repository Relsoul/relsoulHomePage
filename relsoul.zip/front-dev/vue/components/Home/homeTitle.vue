<template>
   <div class="home-title red lighten-2">
       <div class="container">
           <h1>哦~ 你找到了一个神秘的地方</h1>
           <p>欢迎来到我的个人主页</p>
           <a class="waves-effect waves-light btn-large"><i class=" material-icons left">group add</i>Find me</a>
       </div>
   </div>
</template>
<style>

</style>
<script>

    export default{
        data(){
            return{
                msg:'hello vue'
            }
        },
        components:{

        }
    }
</script>