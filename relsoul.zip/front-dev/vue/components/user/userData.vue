<template>
    <div class="user-data">
        <p>{{user.name}}</p>
    </div>
</template>
<style>

</style>
<script type="text/ecmascript-6">

    export default{
        data(){
            return{

            }
        },
        ready(){
            $.tokenAjax("/me","get").then((data)=>{
                console.log("userData",data)

            }).catch()

        },
        components:{

        }
    }
</script>